package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.app.model.Student;
import com.app.service.StudentService;

import jakarta.servlet.http.HttpSession;

@Controller
public class PostController {

	@Autowired
	StudentService studentService;
	
	@PostMapping("/add")
	public String addStudent(@ModelAttribute Student student) {
	    studentService.saveStudent(student); // Save the new student
	    return "redirect:/";
	}
	
    @PostMapping("/edit")
    public String updateStudent(@ModelAttribute Student student,HttpSession session) {
        Long id = (Long) session.getAttribute("id");
        System.out.println("post id "+id);        
    	student.setId(id);
        studentService.saveStudent(student);
        return "redirect:/";
    }
    @PostMapping("/delete/{id}")
    public String deleteStudent(@PathVariable("id") Long id) {
    	System.out.println(id);
        studentService.deleteStudentByRollNumber(id);
        return "redirect:/"; 
    }
	
	
}
