package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.model.Student;
import com.app.repository.StudentRepo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Service
public class StudentService{

	@Autowired
	StudentRepo studentRepo;
	
	public Student getStudentById(Long id) {
		
		return studentRepo.findById(id).orElse(null);
	}

	public void saveStudent(Student student) {
		studentRepo.save(student);
	}

	public List<Student> getAllStudents() {
		return studentRepo.findAll();
	}

	public void deleteStudentByRollNumber(Long id) {
		 System.out.println("service "+id);
	        studentRepo.deleteById(id);
	}
	 
}
