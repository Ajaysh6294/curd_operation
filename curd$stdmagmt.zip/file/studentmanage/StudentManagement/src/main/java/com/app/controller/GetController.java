package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.app.model.Student;
import com.app.service.StudentService;

import jakarta.servlet.http.HttpSession;
import jakarta.websocket.Session;

@Controller
public class GetController {

	@Autowired
	StudentService studentService;
	
//	@GetMapping("/")      
//	public String index(Model model) {
//	    model.addAttribute("student", new Student()); 
//	    return "index"; 
//	}
	
	@GetMapping("/add")
	public String showAddStudentForm(Model model) {
	    model.addAttribute("student", new Student()); 
	    return "add"; 
	}
	
	@GetMapping("/edit/{id}")
	    public String editStudent(@PathVariable("id") Long id, Model model,HttpSession session) {
	        Student student = studentService.getStudentById(id);
	        System.out.println("edit id "+id);
	        session.setAttribute("id", id);
	        System.out.println("name "+student);
			/*
			 * // System.out.println("rollnumber "+student.getRollNumber()); //
			 * System.out.println("marks "+student.getMarks());
			 */	        model.addAttribute("student", student);
	        return "edit"; 
	}

    @GetMapping("/")
    public String getAllStudents(Model model) {
        List<Student> students = studentService.getAllStudents();
        
        model.addAttribute("students", students); 
      
        return "index"; 
    }
    
    
}
