// Edit student action
function editStudent(studentId) {
    window.location.href = `/students/edit/${studentId}`;
}

// Delete student action with confirmation
function deleteStudent(studentId) {
    const confirmation = confirm("Are you sure you want to delete this student?");
    if (confirmation) {
        fetch(`/students/delete/${studentId}`, { method: 'GET' })
            .then(response => {
                if (response.ok) {
                    alert("Student deleted successfully!");
                    location.reload(); // Reload the page to update the table
                } else {
                    alert("Failed to delete the student.");
                }
            })
            .catch(error => {
                console.error("Error:", error);
                alert("An error occurred while deleting the student.");
            });
    }
}
