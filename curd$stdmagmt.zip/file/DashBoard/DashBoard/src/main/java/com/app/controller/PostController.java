package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.app.model.Users;
import com.app.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class PostController {

	@Autowired
	private UserRepository userRepository;

	@PostMapping("/signup")
	public String processSignup(@ModelAttribute("user") Users user, Model model) {
		System.out.println("Name: " + user.getName());
		System.out.println("Email: " + user.getEmail());
		System.out.println("Password: " + user.getPassword());

		try {
			Users existingUser = userRepository.findByEmail(user.getEmail());
			if (existingUser != null) {
				model.addAttribute("error", "Email is already in use.");
				return "/register";
			}

			userRepository.save(user);

			model.addAttribute("success", "Registration successful! Please log in.");
			return "login";
		} catch (Exception e) {
			model.addAttribute("error", "An error occurred during registration.");
			return "/register";
		}
	}

	@PostMapping("/login")
	public String processLogin(String email, String password, HttpSession session, Model model) {
		System.out.println(password);
		System.out.println(email);
		try {
			Users user = userRepository.findByEmail(email);

			if (user != null && user.getPassword().equals(password)) {
				session.setAttribute("name", user.getName());
				return "redirect:/dashboard";
			} else {
				model.addAttribute("error", "Invalid email or password.");
				return "login";
			}

		} catch (Exception e) {
			model.addAttribute("error", "User not found or invalid credentials.");
			return "login";
		}
	}

}
